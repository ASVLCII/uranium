# allow: SIZE_OK -- Central argparse registry intentionally keeps all command wiring cohesive and auditable.
from __future__ import annotations

import argparse
import sys

from ..version import __version__
from ..maintenance.build_identity import build_identity_summary, probe_build_identity
from ..installer import OmhError
from .achievements import (
    _add_achievements_commands,
    cmd_achievements_export,
    cmd_achievements_list,
    cmd_achievements_show,
    cmd_achievements_summary,
)
from .capabilities import (
    _add_capabilities_commands,
    cmd_capabilities_export,
    cmd_capabilities_inspect,
    cmd_capabilities_list,
)
from .chat import (
    _add_chat_commands,
    cmd_chat_interact,
    cmd_chat_route,
    cmd_chat_route_hint,
    cmd_chat_session_decision,
    cmd_chat_session_list,
    cmd_chat_session_prepare_handoff,
    cmd_chat_session_select_executor,
    cmd_chat_session_show,
    cmd_chat_session_start,
    cmd_chat_session_status,
)
from .coding import (
    _add_coding_commands,
    cmd_coding_delegate,
    cmd_coding_dynamic_workflow,
    cmd_coding_executor_readiness,
    cmd_coding_lifecycle_dispatch,
    cmd_coding_lifecycle_report,
    cmd_coding_lifecycle_result,
    cmd_coding_lifecycle_start,
    cmd_coding_lifecycle_verify,
)
from .codegraph import _add_codegraph_commands, cmd_codegraph_build, cmd_codegraph_handoff, cmd_codegraph_summary
from .bare_launch import (
    _TUI_PASSTHROUGH_OPTIONS,
    _auto_update_complete_line,
    _auto_update_started_line,
    _hermes_passthrough_argv,
    _launch_hermes_tui,
    _node_available,
    _omh_tui_blocker,
    _print_exit_card,
    _print_welcome,
    _run_auto_update,
    _run_hermes_fallback,
    _run_startup_update_check,
    _run_terminal,
    _tui_omh_home,
    add_top_level_options,
    run_bare_launch,
)
from .common import set_json_output_pretty
from .context import _add_context_commands, cmd_context_brief
from .model_chains import _add_model_chains_commands
from .conformance import _add_conformance_commands, cmd_conformance_check
from .demo import _add_demo_commands, cmd_demo_orchestration
from .design import _add_design_commands, cmd_design_data
from .docs import (
    _add_docs_commands,
    _add_harness_commands,
    cmd_docs_workflows,
    cmd_harness_inspect,
    cmd_harness_list,
    cmd_harness_validate,
)
from .ecosystem import (
    _add_ecosystem_commands,
    cmd_ecosystem_awesome_inspect,
    cmd_ecosystem_awesome_list,
    cmd_ecosystem_awesome_outcomes,
    cmd_ecosystem_awesome_summary,
)
from .goal import (
    _add_goal_commands,
    cmd_goal_blocker,
    cmd_goal_checkpoint,
    cmd_goal_complete,
    cmd_goal_continue,
    cmd_goal_create,
    cmd_goal_status,
)
from .handoff_risk_scan import add_handoff_risk_scan_command
from .hermes import _add_hermes_commands, cmd_hermes_plan
from .hud import _add_hud_commands, cmd_hud
from .learning import (
    _add_learning_commands,
    cmd_learning_audit,
    cmd_learning_candidate,
    cmd_learning_eval,
    cmd_learning_export,
    cmd_learning_index_check,
    cmd_learning_index_rebuild,
    cmd_learning_list,
    cmd_learning_record,
    cmd_learning_regression_add,
    cmd_learning_regression_replay,
    cmd_learning_show,
)
from .loop import _add_loop_commands, cmd_loop_feedback, cmd_loop_permit, cmd_loop_run_once, cmd_loop_start, cmd_loop_status
from .materials import (
    _add_materials_commands,
    cmd_materials_export,
    cmd_materials_list,
    cmd_materials_plan,
    cmd_materials_qa_ladder,
    cmd_materials_show,
    cmd_materials_validate,
)
from .menubar import _add_menubar_commands, cmd_menubar_status
from .memory import (
    _add_memory_commands,
    cmd_memory_apply,
    cmd_memory_approve,
    cmd_memory_capture,
    cmd_memory_inspect,
    cmd_memory_pack,
    cmd_memory_recall,
    cmd_memory_reject,
    cmd_memory_review,
    cmd_memory_status,
)
from .mcp import (
    _add_mcp_commands,
    cmd_mcp_config_recipe,
    cmd_mcp_manifest,
    cmd_mcp_observe_host,
    cmd_mcp_serve,
    cmd_mcp_sessions,
)
from .plugin import _add_plugin_commands, cmd_plugin_observations, cmd_plugin_observe_host
from .quickstart import _add_quickstart_commands, cmd_quickstart
from .ops import (
    _add_ops_commands,
    cmd_ops_agent_review,
    cmd_ops_agent_review_list,
    cmd_ops_agent_review_show,
    cmd_ops_blueprint,
    cmd_ops_blueprint_list,
    cmd_ops_blueprint_show,
    cmd_ops_export,
    cmd_ops_list,
    cmd_ops_research_department,
    cmd_ops_research_department_list,
    cmd_ops_research_department_show,
    cmd_ops_show,
    cmd_ops_validate,
    cmd_ops_write,
)
from .paper import (
    _add_paper_commands,
    cmd_paper_list,
    cmd_paper_plan,
    cmd_paper_progress,
    cmd_paper_show,
    cmd_paper_validate,
)
from .playbook import _add_playbook_commands, cmd_playbook_inspect, cmd_playbook_list, cmd_playbook_recommend
from .release import _add_release_commands, cmd_release_checklist, cmd_release_hermes_smoke
from .runtime import (
    _add_runtime_commands,
    cmd_runtime_ci,
    cmd_runtime_delegate,
    cmd_runtime_delegation_status,
    cmd_runtime_export,
    cmd_runtime_merge,
    cmd_runtime_record,
    cmd_runtime_review,
    cmd_runtime_runs,
    cmd_runtime_show,
    cmd_runtime_status,
    cmd_runtime_team_readiness,
    cmd_runtime_validate,
    cmd_runtime_wrapper,
)
from .setup import (
    _add_top_level_commands,
    cmd_apply,
    cmd_convert,
    cmd_doctor,
    cmd_install,
    cmd_list,
    cmd_profile_inspect,
    cmd_profile_list,
    cmd_probe,
    cmd_recommend,
    cmd_setup,
    cmd_skill_profile_reconcile,
    cmd_skill_profile_status,
    cmd_snippet,
    cmd_uninstall,
    cmd_update,
)
from .state import _add_state_commands, cmd_state_clear, cmd_state_finish, cmd_state_start, cmd_state_status
from .theme import _add_theme_commands
from .update_check import _add_update_check_commands
from .use_cases import _add_cases_commands, cmd_cases_inspect, cmd_cases_list, cmd_cases_recommend
from .visual import _add_visual_commands, cmd_visual_observe, cmd_visual_prompt_card
from .adapter_quality import _add_adapter_quality_commands
from .cross_harness_benchmark import _add_benchmark_commands
from .quality_evidence import _add_quality_evidence_commands
from .web_qa import _add_web_qa_commands, cmd_web_qa_observe_capture, cmd_web_qa_package, cmd_web_qa_record_verdict
from .worktree import cmd_worktree_bind, cmd_worktree_list, _add_worktree_commands


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="uranium",
        description=(
            "Uranium — a Hermes-native coding workspace. "
            "Based on oh-my-hermes; existing OMH integrations remain compatible.\n"
            "This command is for setup, health checks, local artifacts,\n"
            "and wrapper/backend operations."
        ),
        epilog=(
            "Quick start:\n"
            "  uranium setup\n"
            "  uranium doctor\n"
            "  uranium quickstart\n\n"
            "First five minutes:\n"
            "  1. Run setup, accepting the recommended choices.\n"
            "  2. Restart or reload Hermes Agent.\n"
            "  3. Ask Hermes the prompt below.\n\n"
            "Normal use happens in Hermes chat:\n"
            "  Use OMH request-to-handoff for: I want to safely add a feature to this repo.\n\n"
            "If your shell says `omh` was not found after install, use the absolute\n"
            "command path printed by the installer or add that directory to PATH.\n\n"
            "Operator examples:\n"
            "  uranium recommend \"risky refactor\"\n"
            "  uranium cases recommend \"daily competitor digest\"\n"
            "  uranium cases readiness\n"
            "  uranium cases demo --all\n"
            "  uranium cases artifact --all --write\n"
            "  uranium cases replay\n"
            "  uranium context brief \"make an image card for this PR\"\n"
            "  uranium design data --kind palette --context fintech\n"
            "  uranium playbook recommend \"turn this issue into a PR\"\n"
            "  uranium chat interact \"turn this issue into a PR-ready plan\"\n"
            "  uranium hud\n"
            "  uranium achievements summary\n"
            "  uranium menubar status\n"
            "  uranium mcp manifest\n"
            "  uranium mcp config-recipe --host codex\n"
            "  uranium release evidence-bundle --version 1.0.5 --write\n"
            "  uranium plugin observe-host --host hermes-agent --session <session-id> --event plugin_load --evidence-ref <host-log>\n"
            "  uranium loop status\n"
            "  uranium ops list\n"
            "  uranium materials list\n"
            "  uranium paper list\n"
            "  uranium img-summary prompt-card --kind github_pr --visual-format auto --section summary:What_changed:Safer_setup_copy\n"
            "  uranium img-summary prompt-card --kind report --aspect-ratio long_scroll --section summary:Executive_summary:Weekly_metrics_changed\n"
            "  uranium worktree list\n"
            "  uranium worktree bind --path .worktrees/risky-refactor --executor codex --session <session-id>\n"
            "  uranium runtime status\n"
            "  uranium runtime team-readiness\n\n"
            "Human-facing maintenance, catalog, and operator checklist commands print summaries by default;\n"
            "pass --json or set OMH_OUTPUT=json when a wrapper needs full payloads.\n"
            "Plain chat preview commands such as chat route, route-hint, and interact are summary-first;\n"
            "pass --json for adapter envelopes.\n"
            "Ledger/control-plane commands such as chat session, coding, runtime, goal, loop,\n"
            "learning, memory, state, harness, release smoke, and demo print JSON by design.\n"
            "JSON stdout is compact by default so supervising-agent context stays bounded;\n"
            "pass --pretty or set OMH_JSON_PRETTY=1 for indented, human-readable output."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    add_top_level_options(parser)
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    _add_top_level_commands(sub)
    _add_quickstart_commands(sub)
    _add_docs_commands(sub)
    _add_harness_commands(sub)
    add_handoff_risk_scan_command(sub)
    _add_cases_commands(sub)
    _add_playbook_commands(sub)
    _add_release_commands(sub)
    _add_demo_commands(sub)
    _add_design_commands(sub)
    _add_chat_commands(sub)
    _add_achievements_commands(sub)
    _add_capabilities_commands(sub)
    _add_conformance_commands(sub)
    _add_context_commands(sub)
    _add_model_chains_commands(sub)
    _add_ecosystem_commands(sub)
    _add_coding_commands(sub)
    _add_codegraph_commands(sub)
    _add_hermes_commands(sub)
    _add_hud_commands(sub)
    status = sub.add_parser("status", help="Alias for `omh hud`; show compact OMH status metadata.")
    status.add_argument("--json", action="store_true", help="Print the full machine-readable HUD payload.")
    status.add_argument("--preset", choices=("minimal", "focused", "full"), default="focused")
    status.add_argument("--limit", type=int, default=3, help="Recent runtime run count to summarize.")
    status.add_argument("--tokens-remaining", type=float, default=None)
    status.add_argument("--token-budget", type=float, default=None)
    status.add_argument("--input-tokens", type=float, default=None)
    status.add_argument("--output-tokens", type=float, default=None)
    status.add_argument("--context-remaining-percent", type=float, default=None)
    status.set_defaults(func=cmd_hud)
    _add_learning_commands(sub)
    _add_loop_commands(sub)
    _add_memory_commands(sub)
    _add_menubar_commands(sub)
    _add_mcp_commands(sub)
    _add_plugin_commands(sub)
    _add_ops_commands(sub)
    _add_materials_commands(sub)
    _add_paper_commands(sub)
    _add_visual_commands(sub)
    _add_adapter_quality_commands(sub)
    _add_benchmark_commands(sub)
    _add_quality_evidence_commands(sub)
    _add_web_qa_commands(sub)
    _add_worktree_commands(sub)
    _add_runtime_commands(sub)
    _add_goal_commands(sub)
    _add_state_commands(sub)
    _add_theme_commands(sub)
    _add_update_check_commands(sub)
    return parser


def _reject_tui_passthrough_with_subcommand(args: argparse.Namespace) -> None:
    """Refuse a bare-launch flag that was given alongside a subcommand.

    Unlike `--omh-home`/`--hermes-home`/`--scope`, these three do not apply to
    a subcommand at all: they are forwarded to `hermes` when the bare launch
    opens the terminal, and there is no terminal here. Ignoring one silently
    would run the subcommand against a profile or session the person believes
    they selected.
    """
    for dest, flag in _TUI_PASSTHROUGH_OPTIONS:
        if getattr(args, dest, None) is not None:
            raise OmhError(
                f"{flag} opens the OH-MY-HERMES terminal and cannot be combined "
                f"with the '{args.command}' command."
            )


def main(argv: list[str] | None = None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    if raw_argv in (["--version"], ["-V"]):
        # The semantic version still leads the line, so every consumer that
        # reads a version out of this output keeps working. The build identity
        # follows it, because two same-version checkouts are exactly the case
        # the version alone cannot tell apart.
        print(build_identity_summary(probe_build_identity()))
        return 0
    parser = build_parser()
    args = parser.parse_args(raw_argv)
    # The command line as typed, for a refusal that must name the same
    # command back (`omh setup --interactive` without a terminal).
    args._argv = raw_argv
    set_json_output_pretty(bool(getattr(args, "pretty", False)))
    if not getattr(args, "command", None):
        return run_bare_launch(args)
    try:
        _reject_tui_passthrough_with_subcommand(args)
        return int(args.func(args))
    except OmhError as exc:
        print(f"omh: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
